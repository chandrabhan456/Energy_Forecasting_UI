import React from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

const LineGraph1 = ({ data }) => (
  <ResponsiveContainer width="100%" height={200}>
    <LineChart data={data}>
      <CartesianGrid strokeDasharray="3 3" />
      <XAxis dataKey="next_pred_hours" tickFormatter={str => str.slice(0, 10)} />
      <YAxis domain={[0, 36000]} ticks={[0, 18000, 36000]} />
      <Tooltip />
      <Legend />
      <Line
        type="monotone"
        dataKey="next_act_data"
        name="Actual Data"
        stroke="#1976d2"
        strokeWidth={3}
        dot={false}
      />
      <Line
        type="monotone"
        dataKey="next_pred_data"
        name="Pred Data"
        stroke="#ff9800"
        strokeDasharray="5 5"
        strokeWidth={3}
        dot={false}
      />
    </LineChart>
  </ResponsiveContainer>
);

export default LineGraph1;
