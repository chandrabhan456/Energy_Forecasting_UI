import React, { useState, useEffect } from "react";
import "./DataConn.css";
import { IoIosClose } from "react-icons/io";
import { RiFileExcel2Fill } from "react-icons/ri";
import Papa from "papaparse";
import { FaDownload } from "react-icons/fa";
import LineGraph1 from "./Graphs/LineGraph1";
const csvDataObj = {
  csv_text_index1: `next_pred_hours,next_pred_data,next_act_data
2018-10-09 05:00:00+02:00,22207.168781558,22004.000088097142
2018-10-09 06:00:00+02:00,24204.143489308244,24322.00011314608
2018-10-09 07:00:00+02:00,27020.093386183107,27157.000065415566
2018-10-09 08:00:00+02:00,29173.760766803618,28892.999989132797
`,
};

const DataConnection = () => {
  // State for each button
  const [csvActive, setCsvActive] = useState(true);
  const [databaseActive, setDatabaseActive] = useState(false);
  const [cloudActive, setCloudActive] = useState(false);
  const [csvFiles, setCsvFiles] = useState([]); // Store multiple files
  const [message, setMessage] = useState("");
  const [errmessage, setErrMessage] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [csvFile, setCsvFile] = useState(null);
  const [csvData, setCsvData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [mainBox, setMainBox] = useState(true);
  const [imageUrl, setImageUrl] = useState("");
  const [forecastResult, setForecastResult] = useState(null);
  const [activeButton, setActiveButton] = useState("none");
  const [metrix, setMetrix] = useState(null);
  const [metrix2, setMetrix2] = useState(null);
  const [imageUrl2, setImageUrl2] = useState("");
  const [csvData1, setCsvData1] = useState([]);
  const [indexResult1, setIndexResult1] = useState({});
  const [indexResult2, setIndexResult2] = useState([]);
  const [indexResult3, setIndexResult3] = useState([]);
  const [graphData1, setGraphData1] = useState([]);
  const [graphData2, setGraphData2] = useState([]);
  const [graphData3, setGraphData3] = useState([]);

  const handleFileChange = (event) => {
    console.log("File input event:", event.target.files);
    const files = Array.from(event.target.files); // Convert FileList to array

    // Filter valid files
    const validFiles = files.filter(
      (file) =>
        file.type === "text/csv" ||
        file.type === "application/vnd.ms-excel" ||
        file.type ===
          "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    );

    // Alert if no valid files are selected

    // Map valid files to include metadata
    const newFiles = validFiles.map((file) => ({
      fileObject: file,
      name: file.name,
      type: file.type,
      timestamp: Date.now(),
    }));

    // Append new files to the existing state
    setCsvFiles((prev) => [...prev, ...newFiles]);

    // Clear the file input to allow re-selection of the same file
    event.target.value = null;
  };
  const handleCsvRemove = (fileObject) => {
    console.log("removecsv", fileObject);
    // Filter out the file to be removed
    const updatedFiles = csvFiles.filter(
      (file) => file.name !== fileObject.name
    );
    console.log("updatedcsvFIles", !updatedFiles);
    // Update the state with the remaining files
    setCsvFiles(updatedFiles);
    setMessage("");
    setErrMessage("");
    console.log("updated files", updatedFiles.length);
    if (updatedFiles.length === 0) {
      console.log("empty");
      setCsvFiles([]);
    } else {
      const firstFileURL = URL.createObjectURL(updatedFiles[0].fileObject);
      console.log("firstfileurl", firstFileURL);
      // setCsvFiles(firstFileURL);
    }
  };
  const handleCsvClick = (fileObject) => {
    if (!fileObject) return;
    setActiveButton("file");
    setLoading(true);
    setCsvData([]); // Reset current data before parsing a new file

    let rowCount = 0; // Initialize a counter to track the number of rows parsed

    Papa.parse(fileObject, {
      header: true,
      skipEmptyLines: true,
      worker: true, // Use a web worker for parsing
      chunk: (results, parser) => {
        const newRows = results.data;
        const remainingRows = 20 - rowCount; // Calculate remaining rows needed to reach 20

        if (remainingRows > 0) {
          // Add only the remaining rows needed to reach 20
          setCsvData((prevData) => [
            ...prevData,
            ...newRows.slice(0, remainingRows),
          ]);
          rowCount += newRows.length;

          if (rowCount >= 20) {
            parser.abort(); // Stop parsing once 20 rows have been processed
          }
        }
      },
      complete: () => {
        setLoading(false);
      },
      error: (error) => {
        console.error("Error parsing CSV file:", error);
        setLoading(false);
      },
    });
  };

  useEffect(() => {
    console.log("Updated csvData:", csvData);
  }, [csvFiles, csvData]); // This will run after pdfFiles state is updated

  function parseCSV(csv) {
    const lines = csv.trim().split("\n");
    const headers = lines[0].split(",").map((h) => h.trim());
    return lines.slice(1).map((line) => {
      // This simple parser works for your dummy data, not for complex quoted values
      const values = line.split(",").map((v) => v.trim());
      const obj = {};
      headers.forEach((header, idx) => {
        obj[header] = values[idx];
      });
      return obj;
    });
  }
  const handleUpload = async () => {
    setIsLoading(true);
    // Create a FormData object
    const formData = new FormData();
    setActiveButton("Upload");
    csvFiles.forEach((file) => {
      formData.append("file", file.fileObject); // 'files' is the key used in the backend
    });

    try {
      const response = await fetch("http://127.0.0.1:5000/upload", {
        method: "POST",
        body: formData, // Send FormData directly
      });

      if (!response.ok) {
        throw new Error(`Failed to upload files: ${response.statusText}`);
      }

      const data = await response.json();
      setMessage(data.message);
    } catch (error) {
      console.error("Error creating index:", error);
      setErrMessage(`Error creating index: ${error.message}`);
    } finally {
      setIsLoading(false);
    }
  };
  const handleGenerateForecast = async () => {
    setLoading(true);
    setActiveButton("Graph");
    try {
      const response = await fetch(
        "http://127.0.0.1:5000/forecast/TinyTimeMixerForPrediction/5000/5325/5687",
        {
          method: "POST",
        }
      );

      if (!response.ok) {
        throw new Error(`Failed to fetch image: ${response.statusText}`);
      }

      // Parse JSON response
      const data = await response.json();
      console.log("API response", data);

      // Set base64 image (prepend the proper data URL prefix)
      if (data.csv_text_index1) {
        setIndexResult1(data.csv_text_index1);
        setIndexResult2(data.csv_text_index2);
        setIndexResult3(data.csv_text_index3);
      } else {
        setImageUrl(null);
      }

      if (data.results) {
        setMetrix(data.results);
      } else {
        setMetrix(null);
      }
      // Set metrics if you want to show them in a table
      if (data.results?.Evaluation_Metrics) {
        setMetrix({ Evaluation_Metrics: data.results.Evaluation_Metrics });
      }
    } catch (error) {
      console.error("Error fetching image:", error);
    } finally {
      setLoading(false);
    }
  };

  console.log("Graph data", imageUrl);

  // Handler for "Evaluation Metrix"
  const handleEvaluationMetrix = async () => {
    setLoading(true);
    setActiveButton("Result");
    setForecastResult(null); // Reset before new fetch
    // Your logic here
    try {
      const response = await fetch("http://127.0.0.1:5000/results", {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
        },
      });

      if (!response.ok) {
        throw new Error(`Failed to fetch image: ${response.statusText}`);
      }

      // Parse JSON response
      const data = await response.json();
      console.log("API response", data);

      // Set base64 image (prepend the proper data URL prefix)
      if (data.image_base64) {
        setImageUrl2(`data:image/png;base64,${data.image_base64}`);
      } else {
        setImageUrl2(null);
      }

      if (data.csv_text) {
        const csvText = data.csv_text;
        const parsed = parseCSV(csvText);
        setCsvData1(parsed);
      } else {
        setCsvData1(null);
      }
      // Set metrics if you want to show them in a table
    } catch (error) {
      console.error("Error fetching metrics:", error);
    } finally {
      setLoading(false);
    }
  };
  const handleDownload = async () => {
    try {
      const response = await fetch(
        "http://127.0.0.1:5000/download_csv",

        {
          method: "GET",
        }
      );

      if (!response.ok) {
        throw new Error("Network response was not ok");
      }

      const data = await response.text(); // Expecting { csv_text: "..." }

      const csvText = data;
      console.log(csvText);

      // Create a Blob and trigger download

      const blob = new Blob([csvText], { type: "text/csv" });

      const url = URL.createObjectURL(blob);

      const link = document.createElement("a");

      link.href = url;

      link.download = "Forecast_Results.csv";

      document.body.appendChild(link);

      link.click();

      document.body.removeChild(link);

      URL.revokeObjectURL(url);
    } catch (error) {
      alert("Failed to download CSV file!");

      console.error(error);
    }
  };

  useEffect(() => {
    if (indexResult1 && indexResult1.length > 0) {
      const parsed = parseCSV(indexResult1);
      setGraphData1(parsed);
      console.log("parsed data:", parsed);
    }
    if (indexResult2 && indexResult2.length > 0) {
      const parsed = parseCSV(indexResult2);
      setGraphData2(parsed);
      console.log("parsed data:", parsed);
    }
    if (indexResult3 && indexResult3.length > 0) {
      const parsed = parseCSV(indexResult3);
      setGraphData3(parsed);
      console.log("parsed data:", parsed);
    } else {
      setGraphData1([]);
    }
  }, [activeButton, csvData1, indexResult1, indexResult2, indexResult3]);

  return (
    <div className="flex flex-col mt-0 ml-10 space-y-2 w-full ">
      <div className="mt-4 ml-[12%] ">
        {csvActive && (
          <>
            <div className="">
              <div className="w-1/2 mt-3 h-32 ml-[15%] flex flex-col items-center bg-blue-50 border-2 border-blue-300 border-dashed rounded-xl p-2 transition hover:shadow-lg hover:bg-blue-100">
                {/* Upload Illustration */}
                <div className="mb-4">
                  <svg width="64" height="64" viewBox="0 0 64 64" fill="none">
                    <rect width="64" height="64" rx="16" fill="#DBEAFE" />
                    <g>
                      <path
                        d="M45.5 46H22.5C17.8056 46 14 42.1944 14 37.5C14 33.2254 17.4992 29.6838 21.7094 29.5127C22.9441 25.0228 27.0519 22 32 22C36.9481 22 41.0559 25.0228 42.2906 29.5127C46.5008 29.6838 50 33.2254 50 37.5C50 42.1944 46.1944 46 41.5 46H45.5Z"
                        fill="#60A5FA"
                      />
                      <path
                        d="M32 38V27"
                        stroke="#2563EB"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      />
                      <path
                        d="M28 31L32 27L36 31"
                        stroke="#2563EB"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      />
                    </g>
                  </svg>
                </div>
                {/* File Input */}
                <input
                  id="file-upload"
                  type="file"
                  multiple
                  accept=".csv, .xls, .xlsx"
                  onChange={handleFileChange}
                  className="hidden"
                />
                <label
                  htmlFor="file-upload"
                  className="cursor-pointer text-blue-700 font-medium text-lg dark:text-[#D3D3D3]"
                >
                  Upload file here,{" "}
                  <span className="underline">click to browse</span>
                  {/* <div className="text-xs text-center text-blue-400 mt-2">
                    Supported: .csv, .xls, .xlsx
                  </div> */}
                </label>
                {csvActive && (
                  <>
                    <div className="  mt-2">
                      <div className="file-info    ">
                        {csvFiles.length > 0 && (
                          <div>
                            <div className="  ml-2">
                              {console.log("ramm", csvFiles)}
                              {csvFiles.map((file, index) => (
                                <div key={index} className="flex  mb-2">
                                  {/* Icon based on file type */}
                                  <div className=" ">
                                    {file.type && (
                                      <RiFileExcel2Fill
                                        style={{
                                          color: "green",
                                          marginTop: "4px",

                                          width: "100%", // Use 100% width to fill the allocated space
                                        }}
                                      />
                                    )}
                                  </div>

                                  {/* File Name */}
                                  <p
                                    className="ml-2  truncate dark:text-[#d3d3d3] text-black"
                                    style={{
                                      cursor: "pointer",
                                      overflow: "hidden",
                                      whiteSpace: "nowrap",
                                      textOverflow: "ellipsis",
                                      width: "50%", // Set width to 20% as specified
                                      margin: "0",
                                      marginLeft: "0px",
                                    }}
                                  >
                                    {file.name}
                                  </p>

                                  {/* Preview File Button */}
                                  <button
                                    className="ml-1 text-center text-white bg-blue-500 border border-blue-700 rounded "
                                    style={{
                                      cursor: "pointer",
                                      width: "20%", // Set width to 20% for the button
                                    }}
                                    onClick={() =>
                                      handleCsvClick(file.fileObject)
                                    }
                                  >
                                    Preview
                                  </button>

                                  {/* Remove File Button */}
                                  <button
                                    className="ml-1 text-left text-white bg-red-300 border border-red-300 rounded p-0.1 flex items-center justify-center"
                                    style={{
                                      cursor: "pointer",
                                      width: "20%", // Set width to 20% for the button
                                    }}
                                    onClick={() => handleCsvRemove(file)}
                                  >
                                    Remove
                                  </button>
                                </div>
                              ))}

                              <div className="mt-2 flex space-x-2">
                                {/* Button and Status */}

                                <button
                                  className={`text-lg px-4 py-2 border rounded ${
                                    activeButton === "Upload"
                                      ? "bg-blue-200 border-blue-600"
                                      : "bg-white border-gray-300"
                                  } text-black`}
                                  onClick={handleUpload}
                                >
                                  Upload File
                                </button>

                                <button
                                  className={`text-lg px-4 py-2 border rounded ${
                                    activeButton === "Graph"
                                      ? "bg-blue-200 border-blue-600"
                                      : "bg-white border-gray-300"
                                  } text-black`}
                                  onClick={handleGenerateForecast}
                                >
                                  Generate Forecast
                                </button>

                                <button
                                  className={`text-lg px-4 py-2 border rounded ${
                                    activeButton === "Result"
                                      ? "bg-blue-200 border-blue-600"
                                      : "bg-white border-gray-300"
                                  } text-black`}
                                  onClick={handleEvaluationMetrix}
                                >
                                  Show Results
                                </button>

                                <div
                                  onClick={handleDownload}
                                  style={{ cursor: "pointer" }}
                                >
                                  <FaDownload className="text-lg text-blue-400" />
                                </div>
                              </div>
                              <div>
                                {isLoading && (
                                  <div className="progress-bar-container mt-3">
                                    <div className="progress-bar"></div>
                                  </div>
                                )}
                                {!isLoading && message && (
                                  <p
                                    className="message-box"
                                    style={{
                                      overflow: "hidden", // Prevent overflowing text
                                      whiteSpace: "nowrap", // Prevent wrapping to the next line
                                      textOverflow: "ellipsis", // Add ellipsis for overflow
                                      maxWidth: "98%", // Adjust the width as needed
                                    }}
                                  >
                                    {message}
                                  </p> // Display the success or error message
                                )}
                              </div>
                            </div>
                          </div>
                        )}
                        <div
                          className="item-left "
                          style={{ marginTop: "-12px" }}
                        ></div>
                      </div>
                    </div>
                  </>
                )}
              </div>
              <div className="pdf-info mt-10 justify-center  dark:bg-[#1e1e1e] bg-[#f7f7f7] ">
                {loading && activeButton === "Graph" && (
                  <p
                    className=" shadow-[0_0_24px_4px_theme('colors.blue.200')] rounded-lg text-center text-2xl"
                    style={{ padding: "10px", height: "80%" }}
                  >
                    Generating Forcast...
                  </p>
                )}
                {loading && activeButton === "Result" && (
                  <p
                    className=" shadow-[0_0_24px_4px_theme('colors.blue.200')] rounded-lg text-center text-2xl"
                    style={{ padding: "10px", height: "80%" }}
                  >
                    Generating Result...
                  </p>
                )}

                {activeButton === "file" &&
                  (loading ? (
                    <p
                      className="shadow-[0_0_24px_4px_theme('colors.blue.200')] rounded-lg text-center text-2xl flex items-center justify-center"
                      style={{ padding: "10px", height: "80%" }}
                    ></p>
                  ) : csvData.length > 0 ? (
                    <div
                      className="shadow-[0_0_24px_4px_theme('colors.blue.200')] rounded-lg overflow-auto"
                      style={{ padding: "1px", height: "90%" }}
                    >
                      <table
                        style={{ width: "100%", borderCollapse: "collapse" }}
                      >
                        <thead>
                          <tr>
                            {Object.keys(csvData[0]).map((header, index) => (
                              <th
                                key={index}
                                className="sticky top-0 bg-white z-20 border border-gray-300 px-2 py-2"
                              >
                                {header.charAt(0).toUpperCase() +
                                  header.slice(1)}
                              </th>
                            ))}
                          </tr>
                        </thead>
                        <tbody>
                          {csvData.map((row, rowIndex) => (
                            <tr key={rowIndex}>
                              {Object.values(row).map((value, cellIndex) => (
                                <td
                                  key={cellIndex}
                                  style={{
                                    border: "1px solid #ddd",
                                    padding: "8px",
                                  }}
                                >
                                  {value}
                                </td>
                              ))}
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  ) : (
                    <p className="text-center text-gray-500 text-lg py-10">
                      No data uploaded yet.
                    </p>
                  ))}

                {/* Graph Tab */}
                {activeButton === "Graph" && graphData1.length > 0 && (
                  <div
                    className="shadow-[0_0_24px_4px_theme('colors.blue.200')] rounded-lg overflow-x-auto"
                    style={{ padding: "10px", height: "80%" }}
                  >
                    <div>
                      <p className="text-center font-bold mb-2">
                        Evaluation Matrix
                      </p>
                      <div
                        className="text-center ml-[30%]"
                        style={{ alignItems: "center" }}
                      >
                        <table className="min-w-[340px] justify-center items-center border-collapse border border-gray-400 text-sm">
                          <thead>
                            <tr className="bg-gray-200">
                              <th className="border border-gray-400 px-4 py-2 text-left">
                                #
                              </th>
                              <th className="border border-gray-400 px-4 py-2 text-left">
                                Metric
                              </th>
                              <th className="border border-gray-400 px-4 py-2 text-left">
                                Value
                              </th>
                            </tr>
                          </thead>
                          <tbody>
                            {Object.entries(
                              metrix?.Evaluation_Metrics || {}
                            ).map(([key, value], idx) => (
                              <tr key={key}>
                                <td className="border border-gray-400 px-4 py-1">
                                  {idx + 1}
                                </td>
                                <td className="border border-gray-400 px-4 py-1">
                                  {key.replaceAll("_", " ")}
                                </td>
                                <td className="border border-gray-400 px-4 py-1">
                                  {typeof value === "number"
                                    ? value.toExponential(6)
                                    : value}
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                    <div style={{ marginTop: "0px" }}>
                      <div
                        style={{
                          width: "100%",
                          margin: "2rem auto",
                          height: "200px",
                        }}
                      >
                        <p className="text-center">Example 5000</p>
                        <LineGraph1 data={graphData1} />
                      </div>
                    </div>
                    <div style={{ marginTop: "10px" }}>
                      <div
                        style={{
                          width: "100%",
                          margin: "2rem auto",
                          height: "200px",
                        }}
                      >
                        <p className="text-center">Example 5325</p>
                        <LineGraph1 data={graphData2} />
                      </div>
                    </div>
                    <div style={{ marginTop: "10px" }}>
                      <div
                        style={{
                          width: "100%",
                          margin: "2rem auto",
                          height: "200px",
                        }}
                      >
                        <p className="text-center">Example 5687</p>
                        <LineGraph1 data={graphData3} />
                      </div>
                    </div>
                  </div>
                )}

                {/* Result Tab */}
                {!loading &&
                  activeButton === "Result" &&
                  csvData1.length > 0 && (
                    <div
                      className="shadow-[0_0_24px_4px_theme('colors.blue.200')] rounded-lg overflow-x-auto"
                      style={{ padding: "10px", height: "80%" }}
                    >
                      <div style={{ marginTop: "-300px" }}>
                        <img
                          src={imageUrl2}
                          alt="Plot from backend"
                          style={{
                            width: "100%",
                            height: "800px",
                            objectFit: "contain",
                            display: "block",
                            margin: 0,
                          }}
                        />
                      </div>
                      <div className="ml-[10%]" style={{ marginTop: "-300px" }}>
                        <table className="min-w-[340px] justify-center items-center border-collapse border border-gray-400 text-sm">
                          <thead>
                            <tr className="bg-gray-200">
                              {Object.keys(csvData1[0]).map((header, idx) => (
                                <th
                                  key={idx}
                                  className="border border-gray-400 px-4 py-2 text-left"
                                >
                                  {header.charAt(0).toUpperCase() +
                                    header.slice(1)}
                                </th>
                              ))}
                            </tr>
                          </thead>
                          <tbody>
                            {csvData1.map((row, rowIdx) => (
                              <tr key={rowIdx}>
                                {Object.values(row).map((value, cellIdx) => (
                                  <td
                                    className="border border-gray-400 px-4 py-1"
                                    key={cellIdx}
                                  >
                                    {value}
                                  </td>
                                ))}
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  )}
              </div>
            </div>
          </>
        )}
        {databaseActive && (
          <div>Database Connection Content: Connect to your database here.</div>
        )}
        {cloudActive && (
          <div>Cloud Storage Content: Manage your cloud storage services.</div>
        )}
      </div>
    </div>
  );
};

export default DataConnection;
